(function($) {
	"use strict";
	// For services5.php
	$('.get_service').on('click', function()
	{
		$('html, body').animate({
    scrollTop: $(".tab-content").offset().top
}, 1000);	
	});
	
	
})( jQuery );
